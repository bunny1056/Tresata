"""Run all synthetic cases.  python run_tests.py [--llm] [--threshold 0.7]
Without --llm uses the keyword baseline (no API key needed)."""
import argparse, json, time
from datetime import date
from classifier import keyword_classify, llm_classify
from rules import check_section16, evaluate_line

ap = argparse.ArgumentParser()
ap.add_argument("--llm", action="store_true")
ap.add_argument("--threshold", type=float, default=0.7)
ap.add_argument("--today", default="2026-11-03")
a = ap.parse_args()
today = date.fromisoformat(a.today)

cases = json.load(open("test_cases.json"))
rows, ok = [], 0
for c in cases:
    cl = llm_classify(c["line"], c["ctx"]) if a.llm else keyword_classify(c["line"])
    if a.llm:
        time.sleep(3)  # free-tier rate limit
    if cl["confidence"] < a.threshold and cl["category"] != "unclear":
        cl = {**cl, "category": "unclear", "flag": "low_confidence"}
    res = evaluate_line(cl["category"], c["tax"], c["ctx"], check_section16(c["inv"], today))
    hit = res["status"] == c["expected"]
    ok += hit
    rows.append({"id": c["id"], "line": c["line"], "label": cl["category"],
                 "evidence": cl.get("evidence"), "status": res["status"],
                 "expected": c["expected"], "citations": res["citations"],
                 "eligible_itc": res["eligible_itc"], "pass": hit})
    print(f"{c['id']:>2} {'PASS' if hit else 'FAIL'}  {res['status']:<20} exp={c['expected']:<20} label={cl['category']:<25} {res['citations']}")

print(f"\n{ok}/{len(cases)} correct  ({'LLM' if a.llm else 'keyword baseline'})")
json.dump(rows, open(f"results_{'llm' if a.llm else 'baseline'}.json", "w"), indent=1)
