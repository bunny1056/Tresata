"""Local prototype UI.  pip install streamlit ; streamlit run app.py
Set OPENROUTER_API_KEY to use the LLM classifier; otherwise keyword baseline."""
import json, os
from datetime import date
import streamlit as st
from classifier import keyword_classify, llm_classify
from rules import CATEGORIES, check_section16, evaluate_line, RULE_PACK_VERSION

st.set_page_config(page_title="Blocked-Credit Guard", layout="wide")
st.title("Blocked-Credit Guard — GST ITC checker")
st.caption(f"Rule pack {RULE_PACK_VERSION} · India CGST s.16/17(5) · prototype, not tax advice")
cases = json.load(open("test_cases.json"))
pick = st.selectbox("Load a synthetic case", ["(custom)"] + [f"{c['id']}. {c['line']}" for c in cases])
c = cases[int(pick.split(".")[0]) - 1] if pick != "(custom)" else None

line = st.text_input("Invoice line description", c["line"] if c else "")
tax = st.number_input("GST amount (INR)", value=float(c["tax"]) if c else 1000.0)
col1, col2, col3 = st.columns(3)
act = col1.selectbox("Buyer business activity (CA-confirmed)", ["plastics_manufacturer", "it_services", "fmcg_distributor",
      "passenger_transport", "vehicle_dealer", "caterer", "works_contractor", "auto_parts_trader"],
      index=0 if not c else ["plastics_manufacturer", "it_services", "fmcg_distributor", "passenger_transport", "vehicle_dealer",
      "caterer", "works_contractor", "auto_parts_trader"].index(c["ctx"]["business_activity"]))
same = col2.checkbox("Supplies same category outward", c["ctx"].get("outward_same_category", False) if c else False)
in2b = col3.checkbox("Reflected in GSTR-2B", c["inv"]["in_gstr2b"] if c else True)
idate = st.date_input("Invoice date", date.fromisoformat(c["inv"]["invoice_date"]) if c else date.today())
paid = st.checkbox("Supplier paid", (c["inv"]["paid_date"] is not None) if c else True)
use_llm = st.toggle("Use LLM classifier", bool(os.environ.get("OPENROUTER_API_KEY")))

if st.button("Check ITC", type="primary") and line:
    ctx = {"business_activity": act, "outward_same_category": same}
    cl = llm_classify(line, ctx) if use_llm else keyword_classify(line)
    if cl["confidence"] < 0.7 and cl["category"] != "unclear":
        cl = {**cl, "category": "unclear", "flag": "low_confidence"}
    inv = {"invoice_date": idate.isoformat(), "in_gstr2b": in2b, "paid_date": idate.isoformat() if paid else None}
    res = evaluate_line(cl["category"], tax, ctx, check_section16(inv, date.today()))
    st.subheader(res["status"])
    st.write(f"**Eligible ITC:** {res['eligible_itc']}  ·  **Citations:** {', '.join(res['citations']) or '—'}")
    st.write("**Reasons:**", "; ".join(res["reasons"]))
    st.json({"classifier": "LLM" if use_llm else "keyword", **cl, "label_meaning": CATEGORIES.get(cl["category"])})
    if res["status"] in ("BLOCKED", "HUMAN_REVIEW"):
        st.warning("Routed to CA review queue before GSTR-3B filing.")
