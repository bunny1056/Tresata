# Data & sources
Real public sources (rule pack is built from these):
- CGST Act 2017, s.17 text: https://www.knowyourgst.com/gstlaw/cgst-act/17-apportionment-of-credit-and-blocked-credits-17
- Finance Act 2025 retro amendment to s.17(5)(d): https://taxguru.in/?p=1080251
- s.16 conditions / 16(2)(aa) GSTR-2B / 16(4) time limit: https://gstgyaan.com/section-16-eligibility-conditions-time-limit-for-taking-input-tax-credit
- GST e-invoice JSON schema (input format, ItemList.PrdDesc = line text): https://gstzen.in/a/format-of-e-invoice-schema.html
Synthetic (made up, per assignment rules — no real client data): synthetic_invoice_lines.csv, 14 lines.
