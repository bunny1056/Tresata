"""
Probabilistic layer. Maps invoice line text -> one category + evidence span +
confidence. Two implementations:
  * keyword_classify : non-AI baseline (to show why rules-on-text isn't enough)
  * llm_classify     : OpenRouter free model, strict JSON, closed label set
"""
import json, os, re, urllib.request
from rules import CATEGORIES

KEYWORDS = {
    "motor_vehicle_passenger": ["car", "sedan", "suv", "innova", "vehicle insurance"],
    "food_beverage": ["food", "catering", "lunch", "dinner", "restaurant", "beverage"],
    "club_fitness": ["club", "gym", "fitness"],
    "works_contract_immovable": ["civil work", "construction", "flooring", "roofing"],
    "gift_free_sample": ["gift", "hamper", "free sample"],
    "csr": ["csr"],
    "beauty_health": ["spa", "salon", "health check"],
    "travel_leave_home": ["ltc", "leave travel", "holiday package"],
}


def keyword_classify(text: str) -> dict:
    t = text.lower()
    for cat, kws in KEYWORDS.items():
        for k in kws:
            if re.search(r"\b" + re.escape(k) + r"\b", t):
                return {"category": cat, "evidence": k, "confidence": 0.9}
    return {"category": "normal_input", "evidence": "", "confidence": 0.5}


PROMPT = """You classify ONE line from an Indian GST purchase invoice for input-tax-credit review.
Choose exactly one category key from this list:
{cats}
Rules:
- Judge what is actually supplied and how the buyer uses it, from the text only.
- "evidence" must be an exact substring copied from the input that justifies the label.
- If the text does not let you tell (e.g. vague 'services charges'), use "unclear".
- Do not decide whether credit is allowed. Do not compute tax.
Buyer context: {ctx}
Line: "{line}"
Reply with JSON only: {{"category": "...", "evidence": "...", "confidence": 0.0-1.0}}"""


def llm_classify(text: str, ctx: dict, model=None) -> dict:
    key = os.environ["OPENROUTER_API_KEY"]
    model = model or os.environ.get("OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free")
    cats = "\n".join(f"- {k}: {v}" for k, v in CATEGORIES.items())
    body = json.dumps({"model": model, "temperature": 0,
                       "messages": [{"role": "user", "content": PROMPT.format(
                           cats=cats, ctx=json.dumps(ctx), line=text)}]}).encode()
    req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", data=body,
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    raw = json.load(urllib.request.urlopen(req, timeout=60))["choices"][0]["message"]["content"]
    m = re.search(r"\{.*\}", raw, re.S)
    out = json.loads(m.group(0)) if m else {}
    return validate(out, text)


def validate(out: dict, text: str) -> dict:
    """Guardrails: unknown label or hallucinated evidence -> 'unclear'."""
    cat = out.get("category")
    ev = out.get("evidence", "")
    conf = float(out.get("confidence", 0) or 0)
    if cat not in CATEGORIES:
        return {"category": "unclear", "evidence": "", "confidence": 0.0, "flag": "invalid_label"}
    if cat != "unclear" and ev and ev.lower() not in text.lower():
        return {"category": "unclear", "evidence": ev, "confidence": 0.0, "flag": "evidence_not_in_source"}
    return {"category": cat, "evidence": ev, "confidence": conf}
