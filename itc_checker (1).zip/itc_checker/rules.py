"""
Deterministic rules layer. The LLM NEVER decides eligibility -- it only maps a
messy invoice line to one category from CATEGORIES with a quoted evidence span.
Everything below is plain code a CA can read, version and audit.

Rule pack: CGST Act 2017, Sections 16 and 17(5), as amended by Finance Act 2025
(17(5)(d) "plant or machinery" -> "plant and machinery", retro from 1 Jul 2017).
Jurisdiction: India (GST). Verified Nov 2026. NOT legal advice.
"""
from datetime import date, timedelta

RULE_PACK_VERSION = "IN-GST-ITC-2026.11"

# Closed set of categories the classifier may emit.
CATEGORIES = {
    "normal_input": "Ordinary goods/services used in business",
    "capital_goods_pm": "Plant and machinery (capital goods, not civil structures)",
    "motor_vehicle_passenger": "Motor vehicle <=13 seats, or its repair/insurance/hire",
    "food_beverage": "Food, beverages, outdoor catering",
    "beauty_health": "Beauty treatment, health services, cosmetic surgery",
    "club_fitness": "Club, health or fitness centre membership",
    "travel_leave_home": "Travel benefits to employees on leave/home travel",
    "works_contract_immovable": "Works contract for construction of immovable property",
    "construction_own_account": "Goods/services for building immovable property on own account",
    "personal_use": "Personal consumption",
    "gift_free_sample": "Gifts / free samples",
    "csr": "Used for CSR obligations",
    "lost_destroyed": "Goods lost, stolen, destroyed, written off",
    "unclear": "Cannot tell from the text -> human",
}

# category -> (clause, rule text summary, exception check name or None)
BLOCKED = {
    "motor_vehicle_passenger": ("17(5)(a)/(ab)", "Passenger motor vehicles <=13 seats and related services", "mv_exception"),
    "food_beverage": ("17(5)(b)(i)", "Food & beverages, outdoor catering", "same_line_or_mandated"),
    "beauty_health": ("17(5)(b)(i)", "Beauty, health services, cosmetic surgery", "same_line_or_mandated"),
    "club_fitness": ("17(5)(b)(ii)", "Club / fitness centre membership", None),
    "travel_leave_home": ("17(5)(b)(iv)", "Travel benefits to employees on vacation", "mandated_by_law"),
    "works_contract_immovable": ("17(5)(c)", "Works contract for immovable property (other than plant and machinery)", "further_wc_supply"),
    "construction_own_account": ("17(5)(d)", "Construction of immovable property on own account (Finance Act 2025 wording)", None),
    "personal_use": ("17(5)(g)", "Goods/services for personal consumption", None),
    "gift_free_sample": ("17(5)(h)", "Gifts / free samples", None),
    "csr": ("17(5)(fa)", "Goods/services for CSR obligations", None),
    "lost_destroyed": ("17(5)(h)", "Goods lost, stolen, destroyed, written off", None),
}

MV_EXEMPT_ACTIVITIES = {"vehicle_dealer", "passenger_transport", "driving_school"}


def section16_deadline(invoice_date: date) -> date:
    """16(4): 30 Nov after end of the FY of the invoice (ignoring the
    'annual return filed earlier' branch, which needs GSTR-9 date)."""
    fy_end_year = invoice_date.year + (1 if invoice_date.month >= 4 else 0)
    return date(fy_end_year, 11, 30)


def check_section16(inv: dict, today: date) -> list:
    """Returns list of failed conditions, each with clause. Facts come from
    structured data (GSTR-2B, books), never from the LLM."""
    fails = []
    d = date.fromisoformat(inv["invoice_date"])
    if not inv.get("in_gstr2b", False):
        fails.append(("16(2)(aa)", "Invoice not reflected in GSTR-2B"))
    if not inv.get("goods_received", True):
        fails.append(("16(2)(b)", "Goods/services not yet received"))
    claim = date.fromisoformat(inv.get("claim_date", today.isoformat()))
    if claim > section16_deadline(d):
        fails.append(("16(4)", f"Claim after deadline {section16_deadline(d)}"))
    paid = inv.get("paid_date")
    if paid is None and today > d + timedelta(days=180):
        fails.append(("16(2) 2nd proviso", "Supplier unpaid >180 days: reverse with interest"))
    return fails


def exception_applies(name, ctx: dict) -> bool:
    if name == "mv_exception":
        return ctx.get("business_activity") in MV_EXEMPT_ACTIVITIES
    if name == "same_line_or_mandated":
        return ctx.get("outward_same_category", False) or ctx.get("mandated_by_law", False)
    if name == "mandated_by_law":
        return ctx.get("mandated_by_law", False)
    if name == "further_wc_supply":
        return ctx.get("business_activity") == "works_contractor"
    return False


def evaluate_line(category: str, tax: float, ctx: dict, s16_fails: list) -> dict:
    """Pure function: category + facts -> eligible amount + citation trail."""
    trail = [f"rule_pack={RULE_PACK_VERSION}"]
    if s16_fails:
        return {"eligible_itc": 0.0, "status": "NOT_ELIGIBLE_S16",
                "citations": [c for c, _ in s16_fails],
                "reasons": [r for _, r in s16_fails], "trail": trail}
    if category == "unclear":
        return {"eligible_itc": None, "status": "HUMAN_REVIEW", "citations": [],
                "reasons": ["Classifier could not determine nature of supply"], "trail": trail}
    if category in BLOCKED:
        clause, text, exc = BLOCKED[category]
        if exc and exception_applies(exc, ctx):
            return {"eligible_itc": round(tax, 2), "status": "ELIGIBLE_EXCEPTION",
                    "citations": [clause], "reasons": [f"Blocked by {clause} but exception '{exc}' applies"], "trail": trail}
        return {"eligible_itc": 0.0, "status": "BLOCKED", "citations": [clause],
                "reasons": [text], "trail": trail}
    return {"eligible_itc": round(tax, 2), "status": "ELIGIBLE", "citations": ["16(1)"],
            "reasons": ["Business use; no 17(5) block"], "trail": trail}
