# GST ITC Eligibility Checker (prototype)

Flags purchase-invoice lines whose GST input tax credit is blocked under **Section 17(5)** or fails **Section 16** conditions (CGST Act 2017, India, as amended by Finance Act 2025). Every decision carries a clause citation. A CA signs off on anything uncertain.

**All test data is synthetic and was made up by me.** No real invoices are used. This is not tax advice.

## Design in one line
The LLM only labels what a line *is*, choosing from a closed list, with a quoted evidence span. Deterministic Python decides whether credit is allowed, computes the amount and cites the clause.

| File | Role |
|---|---|
| `rules.py` | Versioned rule pack: 17(5) blocks and exceptions, 16(2)/16(4) checks, eligibility function |
| `classifier.py` | `keyword_classify` (non-AI baseline) and `llm_classify` (OpenRouter, JSON, validated) |
| `test_cases.json` | 14 synthetic invoice lines with business context and expected outcome |
| `run_tests.py` | Runs every case and writes `results_*.json` |

## Run
```bash
python run_tests.py                       # keyword baseline, no key needed
export OPENROUTER_API_KEY=sk-or-...
export OPENROUTER_MODEL=meta-llama/llama-3.3-70b-instruct:free   # any free model
python run_tests.py --llm --threshold 0.7
```
Python 3.9+ and the standard library only.

## Results

### Keyword baseline: 7/14
| # | Case | Got | Expected | Why it failed |
|---|---|---|---|---|
| 1 | HDPE granules | HUMAN_REVIEW | ELIGIBLE | No keyword matches, so the default label has low confidence and goes to a human. This is safe but adds work. |
| 4 | "buffet for 300 pax" | HUMAN_REVIEW | BLOCKED | Food is described without the word "food" |
| 5 | "Diwali dry-fruit boxes for dealers" | HUMAN_REVIEW | BLOCKED | A gift is described without the word "gift" |
| 6 | RCC foundation for a moulding machine | BLOCKED | ELIGIBLE | The word "construction" fires, but a machine foundation is plant and machinery under Explanation 1 to s.17 |
| 11 | "Car brake pads … for resale" | BLOCKED | ELIGIBLE | The word "car" fires, but these are trading goods |
| 12 | "Corporate wellness plan … Cult centre" | HUMAN_REVIEW | BLOCKED | A gym is described as "wellness" |
| 14 | Laptops donated to a school under Sch VII | HUMAN_REVIEW | BLOCKED | CSR is described without the word "CSR" |

The baseline makes two kinds of error. Two of its mistakes are **dangerous false decisions** (#6 and #11). Five are **excess reviews**. Adding more keywords only trades one kind for the other, and that is the argument for using a model that reads meaning.

### LLM: run it yourself
I couldn't reach OpenRouter from my build environment. Run `--llm` and paste the table here, together with the model name and date. Cases I expect to remain hard even for an LLM:
- **#6**: whether a foundation counts as plant and machinery is a contested legal question. The correct behaviour may be a low-confidence result that goes to HUMAN_REVIEW.
- **#10**: "Professional charges as per agreement" should be `unclear`. If the model guesses here, that is a failure.
- **Evidence hallucination**: `validate()` turns any evidence string that does not appear in the source into `unclear`.

## Known limitations
- The 16(4) check ignores the "annual return filed earlier" branch.
- Business-context facts, such as the exception flags, are supplied as structured input. They are not inferred. In production they come from a one-time company profile that a CA confirms.
- Rule 42/43 apportionment for mixed use and the reclaim of reversed credit are out of scope.
- The 180-day check uses the run date, not the GSTR-3B period.
